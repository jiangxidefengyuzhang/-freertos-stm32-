#ifndef __LED_H
#define __LED_H

#include "gpio.h"


void LED_Turn_On(void);
void LED_Turn_Off(void);
void LED_Toggle(void);



#endif
