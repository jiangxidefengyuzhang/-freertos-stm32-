#include "LED.h"

/**
 * @description: ����LED
 * @param {LED} led
 */
void LED_Turn_On(void)
{
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_RESET);
}

/**
 * @description: Ϩ��LED
 * @param {LED} led
 */
void LED_Turn_Off(void)
{
    HAL_GPIO_WritePin(LED1_GPIO_Port, LED1_Pin, GPIO_PIN_SET);
}

/**
 * @description: ��תLED��״̬
 * @param {LED} led
 */
void LED_Toggle(void)
{
    HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
}


