#ifndef __PID_H
#define __PID_H

typedef struct {
	float Target;
	float Actual;
	float Actual1;	//微分先行，存储上次实际值
	float Out;
	
	float Kp;
	float Ki;
	float Kd;
	
	float Error0;
	float Error1;
	float ErrorInt;

	float ErrorIntMax;//积分限幅
	float ErrorIntMin;//积分限幅

	float OutMax;
	float OutMin;

	float Outoffset;//输出偏移
} PID_t;
void PID_Init(PID_t *p);

void PID_Update(PID_t *p);

#endif
