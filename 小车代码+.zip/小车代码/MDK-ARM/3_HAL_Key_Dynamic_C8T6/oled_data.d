3_hal_key_dynamic_c8t6\oled_data.o: Hardware\OLED_Data.c
3_hal_key_dynamic_c8t6\oled_data.o: Hardware\OLED_Data.h
3_hal_key_dynamic_c8t6\oled_data.o: D:\STM32\ARM\ARMCC\Bin\..\include\stdint.h
