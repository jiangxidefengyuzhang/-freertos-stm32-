#include "stm32f1xx_hal.h"  // HAL??????
//#include "stm32f10x.h"                  // Device header
#include "PID.h"
void PID_Init(PID_t *p)
{
	p->Target = 0;
	p->Actual = 0;
	p->Actual1 = 0;
	p->Out = 0;
	p->Error0 = 0;
	p->Error1 = 0;
	p->ErrorInt = 0;

}//��ʼ��
void PID_Update(PID_t *p)
{
	p->Error1 = p->Error0;
	p->Error0 = p->Target - p->Actual;
	
	if (p->Ki != 0)
	{
		p->ErrorInt += p->Error0;
		/*????start*/
		if(p->ErrorInt > p->ErrorIntMax){p->ErrorInt = p->ErrorIntMax;}
		if(p->ErrorInt < -p->ErrorIntMax){p->ErrorInt = -p->ErrorIntMax;}
		/*end*/
	}
	else
	{
		p->ErrorInt = 0;
	}
	
	p->Out = p->Kp * p->Error0
		   + p->Ki * p->ErrorInt
		   //+ p->Kd * (p->Error0 - p->Error1);
		   - p->Kd * (p->Actual - p->Actual1);//????

	/*????*/
	/*start*/
	if (p->Out > 0) 
		{
			p->Out += p->Outoffset;
		}
		else if (p->Out < 0) 
		{
			p->Out -= p->Outoffset;
		}		

	/*end*/
	if (p->Out > p->OutMax) {p->Out = p->OutMax;}
	if (p->Out < p->OutMin) {p->Out = p->OutMin;}

	p->Actual1 = p->Actual;//????
}
