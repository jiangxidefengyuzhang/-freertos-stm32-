#include "freeRTOS_Demo.h"
//引入freeRTOS相关头文件
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "Key.h"
#include "LED.h"
#include "OLED.h"  
#include "MPU6050.h"
#include "MyI2C.h"
#include "tim.h"
#include "Encoder.h"
#include "Motor.h" 
#include "BlueSerial.h" 
#include "PID.h" 
#include "NRF24L01.h" 
#include <math.h>/**/
#include <stdlib.h>/**/
/*=========全局变量=========*/
/*定义角度环二值信号量AngleSemaphore 
相当于 “门铃”
定时器：每 10ms 按一下门铃
balance_task：听到门铃就跑一次控制
结果：10ms 精准运行，小车能站稳
*/
SemaphoreHandle_t AngleSemaphore; 
/*速度环二值信号量*/
SemaphoreHandle_t SpeedSemaphore;
volatile uint8_t RunFlag = 0;
/*俯仰角与互补滤波*/
int16_t AX,AY,AZ,GX,GY,GZ;
float AngleACC;
float AngleGYRO;
float Angle;
/*角度环输出PWM*/
int16_t LeftPWM,RightPWM;
int16_t AvePWM,DifPWM;
/*速度环参数*/
float LeftSpeed,RightSpeed;
float AveSpeed,DifSpeed;
uint8_t KeyNum;
/*=======角度环PID参数========*/
PID_t AnglePID = {
	.Kp = 4,
	.Ki = 0.15,
	.Kd = 4,
	.OutMax = 100,
	.OutMin = -100,

    .Outoffset = 3,

    .ErrorIntMax = 600,
    .ErrorIntMin = -600,
};
#define ANGLE_PERIOD_MS         10      // 角度环：10ms 执行一次
/*=======速度环PID参数========*/
PID_t SpeedPID = {
	.Kp = 2,
    .Ki = 0,
    .Kd = 0,
    .OutMax = 10,
    .OutMin = -10,

    .ErrorIntMax = 150,
    .ErrorIntMin = -150,
};
#define SPEED_PERIOD_MS         50      // 速度环：50ms 执行一次
/*启动任务配置*/
/*仅在启动时执行一次，优先级和堆栈都给最低即可*/
void start_task(void *args);
#define START_TASK_STACK_SIZE 128
#define START_TASK_PRIORITY 1
TaskHandle_t start_task_handle;
//#define START_TASK_PERIOD 100

/*任务1 balance_task的配置*/

void  balance_task(void *args);
#define BALANCE_TASK_STACK_SIZE 512
#define BALANCE_TASK_PRIORITY 3
TaskHandle_t  balance_task_handle;
//#define BALANCE_TASK_PERIOD 10

void  speed_task(void *args);
#define SPEED_TASK_STACK_SIZE 256
#define SPEED_TASK_PRIORITY 2
TaskHandle_t  speed_task_handle;
//#define BALANCE_TASK_PERIOD 10
/*任务2 com_task的配置*/

void  com_task(void *args);
#define COM_TASK_STACK_SIZE 256
#define COM_TASK_PRIORITY 1
TaskHandle_t  com_task_handle;
#define COM_TASK_PERIOD 50

/*任务3 show_task的配置*/

void show_task(void *args);
#define SHOW_TASK_STACK_SIZE 256
#define SHOW_TASK_PRIORITY 1
TaskHandle_t show_task_handle;
#define SHOW_TASK_PERIOD 100



//启动freeRTOS
void StartFreeRTOS(void)
{
    //0.创建二值信号量
    AngleSemaphore = xSemaphoreCreateBinary(); 
    SpeedSemaphore = xSemaphoreCreateBinary(); 
    //1.创建任务
    //#1.函数介绍
    //xTaskCreate（函数地址（函数名），字符串名字（别名，一般和函数名保持一致）
    //，栈大小（最低128，32位系统对应512字节），形参（一般NULL），优先级（0-4，1最小4最大），任务句柄地址(&TaskHandle_t里的内容)）
    xTaskCreate(start_task, "start_task", START_TASK_STACK_SIZE, NULL, START_TASK_PRIORITY, &start_task_handle);
    //2.启动调度器：会自动创建空闲任务
    vTaskStartScheduler();


}
//启动任务：用来创建其他Task
void start_task(void *args)
{
    //进入临界区，保护临界区里的代码，防止它被中断
    taskENTER_CRITICAL();
    //task1
    xTaskCreate(balance_task, "balance_task", BALANCE_TASK_STACK_SIZE, NULL, BALANCE_TASK_PRIORITY, &balance_task_handle);
        // Task 2: 速度环 (优先级 2) -- 新增
    xTaskCreate(speed_task, "speed_task", SPEED_TASK_STACK_SIZE, NULL, SPEED_TASK_PRIORITY, &speed_task_handle);
    //task2
    xTaskCreate(com_task, "com_task", COM_TASK_STACK_SIZE, NULL, COM_TASK_PRIORITY, &com_task_handle);
    //task3
    xTaskCreate(show_task, "show_task", SHOW_TASK_STACK_SIZE, NULL, SHOW_TASK_PRIORITY, &show_task_handle);
    //退出临界区（和进入成对出现）
    taskEXIT_CRITICAL();

    /*删除启动任务自己，因为只需要执行一次*/
    vTaskDelete(NULL);

    //这里有疑问，先退再删还是先删再退？
}
//balance_task：传感器采集 + 姿态解算 + PID 控制 + 电机输出 + 安全保护

void balance_task(void *args)
{
    while (1)
    {
        // 等待 10ms 中断信号（核心！）
        xSemaphoreTake(AngleSemaphore, portMAX_DELAY);
        // ------------ 以下是原来中断里的代码 ------------
        MPU6050_GetData(&AX,&AY,&AZ,&GX,&GY,&GZ);
        GY -= 53;

        // 姿态解算
        AngleACC = -atan2(AX, AZ) / 3.14159f * 180.0f;
        AngleACC += 4.5f;
        AngleGYRO = Angle + GY / 32768.0f * 2000.0f * 0.01f;
        float Alpha = 0.01f;
        Angle = Alpha * AngleACC + (1 - Alpha) * AngleGYRO;

        // 倒地保护
        if (Angle > 50 || Angle < -50) {
            RunFlag = 0;
        }

        // PID + 电机控制
        if (RunFlag) 
        {
            /*角度环代码*/
            AnglePID.Actual = Angle;
            PID_Update(&AnglePID);
            AvePWM = -AnglePID.Out;
            /*控制逻辑*/
            LeftPWM  = AvePWM + DifPWM / 2;
            RightPWM = AvePWM - DifPWM / 2;
            /*输出PWM限幅*/
            if (LeftPWM > 100)   LeftPWM = 100;
            if (LeftPWM < -100)  LeftPWM = -100;
            if (RightPWM > 100)  RightPWM = 100;
            if (RightPWM < -100) RightPWM = -100;
            /*PWM输出*/
            Motor_SetPWM(1, LeftPWM);
            Motor_SetPWM(2, RightPWM);
        }
         else
        {
            Motor_SetPWM(1, 0);
            Motor_SetPWM(2, 0);
        }


    }


}
void speed_task(void *args)
{
    while (1)
    {
        // 只等速度信号量
        xSemaphoreTake(SpeedSemaphore, portMAX_DELAY);

        LeftSpeed = Encoder_Get(1)/44.0/0.05/9.27666;
        RightSpeed = Encoder_Get(2)/44.0/0.05/9.27666;
            
        AveSpeed = (LeftSpeed + RightSpeed )/2.0;
        DifSpeed = LeftSpeed - RightSpeed ;
		
		if(RunFlag)
		{
			SpeedPID.Actual = AveSpeed;//平均速度值给到SpeedPID结构体里面的Actual
			PID_Update(&SpeedPID);//把SpeedPID结构体的各个参数传入到PID_Update函数封装框架内
			AnglePID.Target = SpeedPID.Out;//速度环PID输出值给角度环Target
		
			
		}
    }
}
//com_task：蓝牙通信 + 遥控指令解析 + PID 调参
void com_task(void *args)
{
    TickType_t xLastWakeTime = xTaskGetTickCount();

    while (1)
    {
    if(RunFlag == 1)
	{
	LED_Turn_On();
	}
	else
	{
	LED_Turn_Off();
	} 
    
    //按键2控制启停
    KeyNum = Key_GetNum();
	if(KeyNum == 4)
	{
	if (RunFlag == 0)
			{
            //防止倒地后积分过饱和
			PID_Init(&AnglePID);
			PID_Init(&SpeedPID);            
			RunFlag = 1;
			}
			else
			{
			RunFlag = 0;
			}
	}
        //printf("Task2运行\r\n");
        if (BlueSerial_RxFlag == 1)
        {
            char *Tag = strtok(BlueSerial_RxPacket, ",");
            if (strcmp(Tag, "slider") == 0)
            {
                char *Name  = strtok(NULL, ",");
                char *Value = strtok(NULL, ",");

                taskENTER_CRITICAL();
                /*在这里添加滑块调参参数*/
                if      (strcmp(Name, "AngleKp") == 0)  AnglePID.Kp = atof(Value);
                else if (strcmp(Name, "AngleKi") == 0)  AnglePID.Ki = atof(Value);
                else if (strcmp(Name, "AngleKd") == 0)  AnglePID.Kd = atof(Value);
                else if(strcmp(Name, "SpeedKp") == 0)   SpeedPID.Kp = atof(Value);
				else if(strcmp(Name, "SpeedKi") == 0)   SpeedPID.Ki = atof(Value);
				else if(strcmp(Name, "SpeedKd") == 0)   SpeedPID.Kd = atof(Value);
				else if(strcmp(Name, "Offset") == 0)  AnglePID.Outoffset = atof(Value);                
                taskEXIT_CRITICAL();
            }
            else if (strcmp(Tag, "joystick") == 0)
            {
                /*摇杆控制*/
                int8_t LH = atoi(strtok(NULL, ","));
                int8_t LV = atoi(strtok(NULL, ","));
                int8_t RH = atoi(strtok(NULL, ","));
                int8_t RV = atoi(strtok(NULL, ","));

                taskENTER_CRITICAL();
                /*摇杆值赋值*/
				SpeedPID.Target = LV/25.0;
				DifPWM = RH / 2;
                taskEXIT_CRITICAL();
            }
            BlueSerial_RxFlag = 0;
        }
        /*蓝牙串口打印加速度计角度，陀螺仪计角度以及最终俯仰角*/
        BlueSerial_Printf("[plot,%f,%f,%f]", AngleACC, AngleGYRO, Angle);

        if(NRF24L01_Receive() == 1)
	{
		uint8_t ID = NRF24L01_RxPacket[0];

		if(ID == 0X00 || ID == 0X01)
		{
			/*遥控器发出01数据包后，既能读取遥控器数据，又能实现回传*/
			if(ID == 0X01)
			{
			NRF24L01_TxPacket[0] =0X02;
			NRF24L01_TxPacket[1] =(int8_t)LeftPWM;
			NRF24L01_TxPacket[2] =(int8_t)RightPWM;
			*(float *)&NRF24L01_TxPacket[4] =Angle;
			*(float *)&NRF24L01_TxPacket[8] =LeftSpeed;
			*(float *)&NRF24L01_TxPacket[12] =RightSpeed;
			NRF24L01_Send();
			}
		int8_t LH = NRF24L01_RxPacket[1];
		int8_t LV = NRF24L01_RxPacket[2];
		int8_t RH = NRF24L01_RxPacket[3];
		int8_t RV = NRF24L01_RxPacket[4];
		SpeedPID.Target = LV/25.0;
		DifPWM = RH / 2;

		
		}
        //显示接收到遥控器的数据
		//OLED_Printf(0,56,OLED_6X8,"R:%02X %02X %02X %02X %02X",NRF24L01_RxPacket[0],NRF24L01_RxPacket[1],NRF24L01_RxPacket[2],NRF24L01_RxPacket[3],NRF24L01_RxPacket[4]);
		//OLED_Update();

	}

    vTaskDelayUntil(&xLastWakeTime, COM_TASK_PERIOD);
    }

}

//task3：判断按键KEY1是否按下，按下则删掉task1。
void show_task(void *args)
{
        // 获取当前的基准时间
    TickType_t xLastWakeTime = xTaskGetTickCount();

    while (1)
    {
    //PC13LED指示启停情况
	
        
        // 进入临界区读取数据
        taskENTER_CRITICAL();

        float p = AnglePID.Kp;
        float i = AnglePID.Ki;
        float d = AnglePID.Kd;
        float tar = AnglePID.Target;
        float act = AnglePID.Actual;
        float out = AnglePID.Out;
        float acc = AngleACC;
        //退出临界区
        taskEXIT_CRITICAL();
        //OLED显示参数
        
        OLED_Clear();
        OLED_Printf(0, 0, OLED_6X8, "P:%05.2f", p);
        OLED_Printf(0, 8, OLED_6X8, "I:%05.2f", i);
        OLED_Printf(0, 16, OLED_6X8, "D:%05.2f", d);
        OLED_Printf(0, 24, OLED_6X8, "Tar:%+05.1f", tar);
        OLED_Printf(0, 32, OLED_6X8, "Actu:%+05.1f", act);
        OLED_Printf(0, 40, OLED_6X8, "Ang:%+05.1f", acc);
        OLED_Printf(0, 48, OLED_6X8, "Out:%+05.0f", out);
        OLED_Printf(64, 0, OLED_6X8, "SP:%05.2f", SpeedPID.Kp);
        OLED_Printf(64, 8, OLED_6X8, "SI:%05.2f", SpeedPID.Ki);
        OLED_Printf(64, 16, OLED_6X8, "SD:%05.2f", SpeedPID.Kd);
        OLED_Printf(64, 24, OLED_6X8, "ST:%+05.1f", SpeedPID.Target);
        OLED_Printf(64, 32, OLED_6X8, "SAct:%+05.1f", SpeedPID.Actual);
        OLED_Printf(64, 40, OLED_6X8, "SO:%+05.0f", SpeedPID.Out);
        //OLED_Printf(64, 0, OLED_6X8, "Off:%+02.0f", AnglePID.Outoffset);      
        OLED_Update();
        
                // 6ms执行一次 接收数据的时间间隔应该等于发送数据的时间间隔
        vTaskDelayUntil(&xLastWakeTime, SHOW_TASK_PERIOD);
    }
}

// 定时器更新中断回调函数
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    static uint16_t Count = 0;
    static uint16_t Count1 = 0; 
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    // 判断是否是 TIM1 中断
    if(htim->Instance == TIM1)
    {
        // 1ms 执行一次：按键消抖
        Key_Tick();

        // 10ms 执行一次：角度互锁  
        Count++;
        if(Count >= ANGLE_PERIOD_MS)
        {
            Count = 0;
            // 释放信号量，唤醒平衡任务
            xSemaphoreGiveFromISR(AngleSemaphore, &xHigherPriorityTaskWoken);
        }
        Count1++;
        if(Count1 >= SPEED_PERIOD_MS)
        {
            Count1 = 0;
            // 释放速度环信号量
            xSemaphoreGiveFromISR(SpeedSemaphore, &xHigherPriorityTaskWoken);
        }
            // 上下文切换
            portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
        
    }
}
